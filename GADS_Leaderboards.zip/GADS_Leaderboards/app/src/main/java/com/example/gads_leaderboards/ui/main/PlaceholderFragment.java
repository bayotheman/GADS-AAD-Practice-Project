package com.example.gads_leaderboards.ui.main;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gads_leaderboards.R;
import com.example.gads_leaderboards.TopLearnerRecyclerAdapter;

import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    private PageViewModel pageViewModel;
    private TopLearnerRecyclerAdapter mTopLearnerRecyclerAdapter;
    private RecyclerView mRecyclerView;
    private Context mContext;
    //private  DataManager dm ;
    String url = "https://gadsapi.herokuapp.com/api/hours";



    public static PlaceholderFragment newInstance(int index) {
        PlaceholderFragment fragment = new PlaceholderFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_leaderboards_tab, container, false);
        //final TextView textView = root.findViewById(R.id.section_label2);
        mRecyclerView = root.findViewById(R.id.recycler_view_learner);
        final LinearLayoutManager learnerLayoutManager = new LinearLayoutManager(root.getContext());
        mRecyclerView.setLayoutManager(learnerLayoutManager);
        String url = "https://gadsapi.herokuapp.com/api/hours";
        DataManager dm = new DataManager();
        dm.extractData(url);
        dm.parseStringToJSON();
        dm.loadTopLearnerList();
       //List<TopLearner> list = DataManager.getInstance("hours").getTopLearnerList();
        List<TopLearner> list = dm.getTopLearnerList();
       mTopLearnerRecyclerAdapter = new TopLearnerRecyclerAdapter(root.getContext(), list);
       mRecyclerView.setAdapter(mTopLearnerRecyclerAdapter);



        pageViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                //textView.setText(s);
                //displayContent()
            }
        });
        return root;
    }

//    private void displayContent() {
//        //final RecyclerView recyclerlist = (RecyclerView) findViewById(R.id.recycler_view_learner);
//        mRecyclerView = (RecyclerView)fin;
//        final LinearLayoutManager notesLayoutManager = new LinearLayoutManager(this);
//        //recyclerNotes.setLayoutManager(notesLayoutManager);
//
//        //List<TopLearner> notes = DataManager.;
//        mNoteRecyclerAdapter = new NoteRecyclerAdapter(this, notes);
//        recyclerNotes.setAdapter(mNoteRecyclerAdapter);
//    }
}
