package com.example.gads_leaderboards;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gads_leaderboards.ui.main.DataManager;
import com.example.gads_leaderboards.ui.main.TopLearner;

import java.util.ArrayList;
import java.util.List;

public class TopLearnerRecyclerAdapter extends RecyclerView.Adapter<TopLearnerRecyclerAdapter.ViewHolder> {
    private final Context mContext;
    private final List<TopLearner> mTopLearnerList;
    private final LayoutInflater mLayoutInflater;

    public TopLearnerRecyclerAdapter(Context context, List<TopLearner> learner){
        mContext = context;
//        mTopLearnerList = new ArrayList<TopLearner>();
//        mTopLearnerList.addAll(learner);
        mTopLearnerList = learner;
        mLayoutInflater = LayoutInflater.from(mContext);
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = mLayoutInflater.inflate(R.layout.item_list, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TopLearnerRecyclerAdapter.ViewHolder holder, int position) {
        TopLearner learner = mTopLearnerList.get(position);
        holder.mName.setText(learner.getName());
        holder.mHours.setText(learner.getHours());
        holder.mCountry.setText(learner.getCountry());
        holder.mCurrentPosition = position;
//        DataManager learner = DataManager.getInstance("hours");
//        holder.mName.setText(learner.getTopLearnerList().get(position).getName());
//        holder.mHours.setText(learner.getTopLearnerList().get(position).getHours());
//        holder.mCountry.setText(learner.getTopLearnerList().get(position).getCountry());
//        holder.mCurrentPosition = position;
//
    }

    @Override
    public int getItemCount() {
        return mTopLearnerList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public final TextView mName;
        public final TextView mHours;
        public final TextView mCountry;
        public int mCurrentPosition;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mName = itemView.findViewById(R.id.toplearner_name);
            mHours = itemView.findViewById(R.id.hours);
            mCountry = itemView.findViewById(R.id.country);
        }
    }
}
