package com.example.gads_leaderboards.ui.main;


import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;

public  class DataManager {
    private static DataManager ourInstance;
    private String mRawData;
    private JSONArray mJSONData;
    private List<TopLearner> mTopLearners;
    private List<TopSkillIQ> mTopSkillIQs;

    public static DataManager getInstance(String apiResource) {
        if(ourInstance == null) {
            ourInstance = new DataManager();
            if(apiResource == "hours") {
                ourInstance.extractData("https://gadsapi.herokuapp.com/api/hours");
                ourInstance.parseStringToJSON();
                ourInstance.getJSONData();
                ourInstance.loadTopLearnerList();
                return ourInstance;

            }else if (apiResource == "skilliq"){
                ourInstance.extractData("https://gadsapi.herokuapp.com/api/skilliq");
                ourInstance.parseStringToJSON();
                ourInstance.getJSONData();
                ourInstance.loadTopSkillIQList();
                return ourInstance;

            }
        }
        return ourInstance;
    }
    public DataManager(){

        mRawData = "";
        mJSONData = new JSONArray();
        mTopLearners = new ArrayList<TopLearner>();
        mTopSkillIQs = new ArrayList<TopSkillIQ>();

    }


    public int getTopLearnersSize(){
        return  mTopLearners.size();
    }

    public int getTopSkillIQSize(){
        return mTopSkillIQs.size();
    }



    public void extractData(String link){

        try{
            URL  url = new URL(link);
            URLConnection connection = url.openConnection();
            HttpURLConnection httpConnection = (HttpURLConnection) connection;
            httpConnection.setRequestMethod("GET");
            httpConnection.connect();
            int code = httpConnection.getResponseCode();
            String message = httpConnection.getResponseMessage();
            if (code != HttpURLConnection.HTTP_OK)
            {
                throw new RuntimeException("HttpResponseCode: " + code + " " + message);
            }

            InputStream inStream = new BufferedInputStream(httpConnection.getInputStream());
            Scanner in = new Scanner(inStream);

            while(in.hasNextLine())
            {
                mRawData +=in.nextLine();
            }
            in.close();
            httpConnection.disconnect();
        }catch(IOException | RuntimeException e){
        }

    }


    public List<TopSkillIQ> getTopSkillIQList(){
        return mTopSkillIQs;
    }


    public List<TopLearner> getTopLearnerList(){
        return mTopLearners;
    }

    public JSONArray getJSONData(){
        return mJSONData;

    }

    public void parseStringToJSON(){
        try {
            mJSONData = new JSONArray(mRawData);
        } catch (JSONException ex) {
            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
        }


    }

    private TopLearner convertToTopLearnerObject(int position ){
        String name = null, country = null;
        int hours = 0;
        try {
            //JSONArray info = parseDataToJSON;
            name = mJSONData.getJSONObject(position).getString("name");
            // score = info.getJSONObject(mPosition).getInt("score");
            hours = mJSONData.getJSONObject(position).getInt("hours");
            country = mJSONData.getJSONObject(position).getString("country");

        } catch (JSONException ex) {
            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return  new TopLearner(name, hours, country);
    }

    private TopSkillIQ convertToTopSkillIQObject(int position ){
        String name = null, country = null;
        int score = 0;
        try {
            //JSONArray info = parseDataToJSON;
            name = mJSONData.getJSONObject(position).getString("name");
            // score = info.getJSONObject(mPosition).getInt("score");
            score = mJSONData.getJSONObject(position).getInt("score");
            country = mJSONData.getJSONObject(position).getString("country");

        } catch (JSONException ex) {
            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return  new TopSkillIQ(name, score, country);
    }

    public void loadTopSkillIQList(){
        int length = mJSONData.length();
        for(int i = 0; i < length; ++i){
            mTopSkillIQs.add(convertToTopSkillIQObject(i));
        }
    }

    public void loadTopLearnerList(){
        int length = mJSONData.length();
        for(int i = 0; i < length; ++i){
            mTopLearners.add(convertToTopLearnerObject(i));
        }
    }
//    private int position ;
//    //private  StudentInfo mStudentInfo ;
//    private JSONArray mTopLearnerData;
//    private JSONArray mTopSkillIQData;
//    private List<TopLearner> mTopLearnerList ;
//    private List<TopSkillIQ> mTopSkillIQList;
//
//    //private long lastModified;
//    private final  String host ="https://gadsapi.herokuapp.com";
//    private final  String[] resource = {"/api/hours", "/api/skilliq"};
////    LocalDateTime dateTime = LocalDateTime.now();
////    LocalTime time = LocalTime.now();
//
//
//    public DataManager(int position){
//        this.position = position;
//        if(position == 0 ){
//            mTopLearnerData = parseDataToJSON();
//
//        }else if(position == 1)
//            mTopSkillIQData = parseDataToJSON();
//
//        else{
//            throw new RuntimeException("Invalid constructor argument, argument should be either 0 or 1");
//        }
//
//    }
//
//    public List<TopLearner> getTopLearnerList(){
//        mTopLearnerList = loadTopLearnerList();
//        return mTopLearnerList;
//    }
//
//    public List<TopSkillIQ> getTopSkillIQList(){
//        mTopSkillIQList = loadTopSkillIQList();
//        return mTopSkillIQList;
//    }
//
//    public int getLength(){
//        if (position == 0)return mTopLearnerData.length();
//        else return mTopSkillIQData.length();
//    }
//
//    public String  getData(){
//        String serverAddress = host + resource[position];
//        String input = "";
//        try{
//            URL  url = new URL(serverAddress);
//            URLConnection connection = url.openConnection();
//            HttpURLConnection httpConnection = (HttpURLConnection) connection;
//            httpConnection.setRequestMethod("GET");
//            httpConnection.connect();
//            int code = httpConnection.getResponseCode();
//            String message = httpConnection.getResponseMessage();
//            if (code != HttpURLConnection.HTTP_OK)
//            {
//                throw new RuntimeException("HttpResponseCode: " + code + " " + message);
//            }
//
//            InputStream inStream = new BufferedInputStream(httpConnection.getInputStream());
//            Scanner in = new Scanner(inStream);
//
//            while(in.hasNextLine())
//            {
//                input +=in.nextLine();
//            }
//            in.close();
//            httpConnection.disconnect();
//        }catch(IOException | RuntimeException e){
//        }
//        return input;
//
//    }
//
//    public JSONArray parseDataToJSON() {
//        String data = getData();
//        JSONArray jsonArray = null;
//
//        try {
//            jsonArray = new JSONArray(data);
//        } catch (JSONException ex) {
//            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
//        return jsonArray;
//    }
//
//
//    public  TopLearner getTopLearnerDetails(int position){
//        String name = null, country = null;
//        int hours = 0;
//        try {
//            JSONArray info = mTopLearnerData;
//            name = info.getJSONObject(position).getString("name");
//            // score = info.getJSONObject(position).getInt("score");
//            hours = info.getJSONObject(position).getInt("hours");
//            country = info.getJSONObject(position).getString("country");
//
//
//        } catch (JSONException ex) {
//            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return  new TopLearner(name, hours, country);
//    }
//
//    public  TopSkillIQ getTopSkillIQDetails(int position){
//        String name = null, country = null;
//        int score = 0;
//        try {
//            JSONArray info = mTopSkillIQData;
//            name = info.getJSONObject(position).getString("name");
//            // score = info.getJSONObject(position).getInt("score");
//            score = info.getJSONObject(position).getInt("score");
//            country = info.getJSONObject(position).getString("country");
//
//
//        } catch (JSONException ex) {
//            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return  new TopSkillIQ(name, score, country);
//    }
//
//    public List<TopLearner> loadTopLearnerList(){
//        List<TopLearner> list = new ArrayList<>();
//        for (int i = 0; i < getLength();++i){
//            list.add(getTopLearnerDetails(i));
//        }
//        return list;
//    }
//
//    public List<TopSkillIQ> loadTopSkillIQList(){
//        List<TopSkillIQ> list = new ArrayList<>();
//        for (int i = 0; i < getLength();++i){
//            list.add(getTopSkillIQDetails(i));
//        }
//        return list;
//    }
}




//public  class DataManager {
//    private int position ;
//    private  StudentInfo mStudentInfo ;
////    private JSONArray mTopLearnerData;
////    private JSONArray mTopSkillIQData;
//    private List<TopLearner> mTopLearners = new ArrayList<>();
//    private List<TopSkillIQ> mTopSkillIQS = new ArrayList<>();
//
//    //private long lastModified;
//    private final  String host ="https://gadsapi.herokuapp.com";
//    private final  String[] resource = {"/api/hours", "/api/skilliq"};
////    LocalDateTime dateTime = LocalDateTime.now();
////    LocalTime time = LocalTime.now();
//
//
//    public DataManager(int position){
//        this.position = position;
//        if(position == 0 ) mTopLearners = loadTopLearnerList();
//        else if(position == 1)
//            mTopSkillIQS = loadTopSkillIQList();
//
//        else{
//            throw new RuntimeException("Invalid constructor argument, argument should be either 0 or 1");
//        }
//
//    }
//
//    public int getLength(){
//        if (position == 0)return mTopLearners.size();
//        else return mTopSkillIQS.size();
//    }
//
//    public String  getData(){
//        String serverAddress = host + resource[position];
//        String input = "";
//        try{
//            URL  url = new URL(serverAddress);
//            URLConnection connection = url.openConnection();
//            HttpURLConnection httpConnection = (HttpURLConnection) connection;
//            httpConnection.setRequestMethod("GET");
//            httpConnection.connect();
//            int code = httpConnection.getResponseCode();
//            String message = httpConnection.getResponseMessage();
//            if (code != HttpURLConnection.HTTP_OK)
//            {
//                throw new RuntimeException("HttpResponseCode: " + code + " " + message);
//            }
//
//            InputStream inStream = new BufferedInputStream(httpConnection.getInputStream());
//            Scanner in = new Scanner(inStream);
//
//            while(in.hasNextLine())
//            {
//                input +=in.nextLine();
//            }
//            in.close();
//            httpConnection.disconnect();
//        }catch(IOException | RuntimeException e){
//        }
//        return input;
//
//    }
//
//    public JSONArray parseDataToJSON() {
//        String data = getData();
//        JSONArray jsonArray = null;
//
//        try {
//            jsonArray = new JSONArray(data);
//        } catch (JSONException ex) {
//            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
//        return jsonArray;
//    }
//
//
//    public  TopLearner getTopLearnerDetails(int position){
//        String name = null, country = null;
//        int hours = 0;
//        try {
//            JSONArray info = parseDataToJSON();
//            name = info.getJSONObject(position).getString("name");
//            // score = info.getJSONObject(position).getInt("score");
//            hours = info.getJSONObject(position).getInt("hours");
//            country = info.getJSONObject(position).getString("country");
//
//
//        } catch (JSONException ex) {
//            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return  new TopLearner(name, hours, country);
//    }
//
//    public  TopSkillIQ getTopSkillIQDetails(int position){
//        String name = null, country = null;
//        int score = 0;
//        try {
//            JSONArray info = parseDataToJSON();
//            name = info.getJSONObject(position).getString("name");
//            // score = info.getJSONObject(position).getInt("score");
//            score = info.getJSONObject(position).getInt("score");
//            country = info.getJSONObject(position).getString("country");
//
//
//        } catch (JSONException ex) {
//            Logger.getLogger(DataManager.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return  new TopSkillIQ(name, score, country);
//    }
//
//    public List<TopLearner> loadTopLearnerList(){
//        List<TopLearner> list = new ArrayList<>();
//        for (int i = 0; i < getLength();++i){
//            list.add(getTopLearnerDetails(i));
//        }
//        return list;
//    }
//
//    public List<TopSkillIQ> loadTopSkillIQList(){
//        List<TopSkillIQ> list = new ArrayList<>();
//        for (int i = 0; i < getLength();++i){
//            list.add(getTopSkillIQDetails(i));
//        }
//        return list;
//    }
//}
//
