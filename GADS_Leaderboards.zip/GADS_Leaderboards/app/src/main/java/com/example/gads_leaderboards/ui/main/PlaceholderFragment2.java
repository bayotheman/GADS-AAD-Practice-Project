package com.example.gads_leaderboards.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gads_leaderboards.R;
import com.example.gads_leaderboards.TopLearnerRecyclerAdapter;
import com.example.gads_leaderboards.TopSkillIQRecyclerAdapter;

import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragment2 extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    private PageViewModel pageViewModel;
    private RecyclerView mRecyclerView;
    private TopSkillIQRecyclerAdapter mTopSkillIQRecyclerAdapter;


    public static PlaceholderFragment2 newInstance(int index) {
        PlaceholderFragment2 fragment = new PlaceholderFragment2();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_leaderboards_tab2, container, false);
        //final TextView textView = root.findViewById(R.id.section_label2);

        mRecyclerView = root.findViewById(R.id.recycler_view_learner);
        final LinearLayoutManager learnerLayoutManager = new LinearLayoutManager(root.getContext());
        mRecyclerView.setLayoutManager(learnerLayoutManager);
        String url = "https://gadsapi.herokuapp.com/api/skilliq";
        DataManager dm = new DataManager();
        dm.extractData(url);
        dm.parseStringToJSON();
        dm.loadTopSkillIQList();
        //List<TopSkillIQ> list = DataManager.getInstance("score").getTopSkillIQList();
        List<TopSkillIQ> list = dm.getTopSkillIQList();
        mTopSkillIQRecyclerAdapter = new TopSkillIQRecyclerAdapter(root.getContext(), list);
        //mTopSkillIQRecyclerAdapter = new TopSkillIQRecyclerAdapter();
        mRecyclerView.setAdapter(mTopSkillIQRecyclerAdapter);

        pageViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                //textView.setText(s);
            }
        });
        return root;
    }

}