package com.example.gads_leaderboards.ui.main;

public class StudentInfo {

        private final String mName ;
        private final String mCountry;

        public StudentInfo(String name, String country){
            mName = name;
            mCountry = country;
        }

        public String getName(){
            return mName;
        }

        public String getCountry(){
            return mCountry;
        }

        public String toString(){
            return " ";
        }
    }

