package com.example.gads_leaderboards.ui.main;

public class TopSkillIQ extends StudentInfo {

    private int mScore = 0 ;

    public TopSkillIQ(String name,int scores, String country){
        super(name, country);
        mScore = scores;
    }

    public int getScore(){
        return mScore;
    }

    private String getCompareKey() {
        return getName() + "|" + mScore+ "|" + getCountry();
    }

    @Override
    public String toString() {
        return getCompareKey();

    }
}