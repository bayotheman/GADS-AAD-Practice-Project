package com.example.gads_leaderboards;

import android.os.Bundle;

import com.example.gads_leaderboards.ui.main.DataManager;
import com.example.gads_leaderboards.ui.main.TopLearner;
import com.google.android.material.tabs.TabLayout;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import com.example.gads_leaderboards.ui.main.SectionsPagerAdapter;

import java.util.List;

public class LeaderboardsTabActivity extends AppCompatActivity {

    private RecyclerView mRecyclerList;
    //private LinearLayoutManager mLayoutManager;
    private RecyclerView mRecyclerView;
    private TopLearnerRecyclerAdapter mTopLearnerRecyclerAdapter;
    private LinearLayoutManager learnerLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboards_tab);
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());

        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);

        //displayContent();
//        learnerLayoutManager = new LinearLayoutManager(this);
//        mRecyclerView.setLayoutManager(learnerLayoutManager);
//        String url = "https://gadsapi.herokuapp.com/api/hours";
////        DataManager dm = new DataManager();
////        dm.extractData(url);
////        dm.parseStringToJSON();
////        dm.getJSONData();
////        dm.loadTopLearnerList();
//        List<TopLearner> list = DataManager.getInstance("hours").getTopLearnerList();
//        mTopLearnerRecyclerAdapter = new TopLearnerRecyclerAdapter(this, list);

            }

//    private void displayContent() {
//        mRecyclerList = (RecyclerView)findViewById(R.id.recycler_view2);
//        mLayoutManager = new LinearLayoutManager(this);
//        mRecyclerList.setLayoutManager(mLayoutManager);


    }


