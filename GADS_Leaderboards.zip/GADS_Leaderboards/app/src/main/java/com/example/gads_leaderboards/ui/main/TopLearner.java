package com.example.gads_leaderboards.ui.main;

public class TopLearner extends StudentInfo {
    private int mHours = 0 ;

    public TopLearner(String name,int hours, String country){
        super(name, country);
        mHours = hours;
    }

    public int getHours(){
        return mHours;
    }
    private String getCompareKey() {
        return getName() + "|" + mHours+ "|" + getCountry();
    }

    @Override
    public String toString() {
        return getCompareKey();
    }
}
