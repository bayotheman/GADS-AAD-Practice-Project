package com.example.gads_leaderboards;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class SubmitActivity extends AppCompatActivity {

    private TextView mFname;
    private TextView mLname;
    private TextView mEmail;
    private TextView mGithub;
    private String mUrl = "https://docs.google.com/forms/d/e/";
    private Retrofit mRetrofit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit);

//        Retrofit retrofit = new Retrofit.Builder().baseUrl(mUrl).build();
//        final SubmissionFormService submissionFormWebService = retrofit.create(SubmissionFormService.class);
        mRetrofit = new Retrofit.Builder().baseUrl(mUrl).build();
        initializeDisplayContent();


    }

    private void initializeDisplayContent() {
        mFname = (TextView)findViewById(R.id.first_name);
        mLname = (TextView)findViewById(R.id.last_name);
        mEmail = (TextView)findViewById(R.id.email);
        mGithub = (TextView)findViewById(R.id.github_link);

    }

    public void onSubmit(View view) {
//        Retrofit retrofit = new Retrofit.Builder().baseUrl(mUrl).build();
//        final SubmissionFormService submissionFormWebService = retrofit.create(SubmissionFormService.class);
//        mRetrofit = new Retrofit.Builder().baseUrl(mUrl).build();
        final SubmissionFormService submissionFormWebService = mRetrofit.create(SubmissionFormService.class);
        String fname = mFname.getText().toString();
        String lname = mLname.getText().toString();
        String email = mEmail.getText().toString();
        String github = mGithub.getText().toString();
        Call<Void> completeForm = submissionFormWebService.completeForm(fname, lname,
                email, github);
        completeForm.enqueue(callBack);
        
    }

    private final Callback<Void> callBack = new Callback<Void>() {
        @Override
        public void onResponse(Call<Void> call, Response<Void> response) {
            Log.d("XXX", "Submitted. " + response);
        }

        @Override
        public void onFailure(Call<Void> call, Throwable t) {
            Log.e("XXX", "Failed", t);
        }

    };
}