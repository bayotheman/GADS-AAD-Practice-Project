package com.example.gads_leaderboards;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.gads_leaderboards.ui.main.DataManager;
import com.example.gads_leaderboards.ui.main.TopLearner;
import com.example.gads_leaderboards.ui.main.TopSkillIQ;

import java.util.ArrayList;
import java.util.List;

public class TopSkillIQRecyclerAdapter extends RecyclerView.Adapter<TopSkillIQRecyclerAdapter.ViewHolder> {
    private Context mContext;
    private final List<TopSkillIQ> mTopSkillIQList;
    private LayoutInflater mLayoutInflater;

    public TopSkillIQRecyclerAdapter(Context context, List<TopSkillIQ> skillIq){
        mContext = context;
//        mTopSkillIQList = new ArrayList<TopSkillIQ>();
//        mTopSkillIQList.addAll(skillIq);
        mTopSkillIQList = skillIq;
        mLayoutInflater = LayoutInflater.from(mContext);
    }

//    public TopSkillIQRecyclerAdapter() {
//        //mTopSkillIQList = new ArrayList<TopSkillIQ>();
//        mTopSkillIQList = DataManager.getInstance("score").getTopSkillIQList();
//        mLayoutInflater = LayoutInflater.from(R.layout.fragment_leaderboards_tab2, parent);
//    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mLayoutInflater.inflate(R.layout.item_list2, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TopSkillIQ learner = mTopSkillIQList.get(position);
        holder.mName.setText(learner.getName());
        holder.mScore.setText(learner.getScore());
        holder.mCountry.setText(learner.getCountry());
        holder.mCurrentPosition = position;

    }

    @Override
    public int getItemCount() {
        return mTopSkillIQList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final TextView mName;
        public final TextView mScore;
        public final TextView mCountry;
        public int mCurrentPosition;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mName = itemView.findViewById(R.id.skilliq_name);
            mScore = itemView.findViewById(R.id.score);
            mCountry = itemView.findViewById(R.id.country1);
        }
    }
}
